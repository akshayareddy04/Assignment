package com.example.curtainmodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Curtainmodel3Application {

	public static void main(String[] args) {
		SpringApplication.run(Curtainmodel3Application.class, args);
	}

}
