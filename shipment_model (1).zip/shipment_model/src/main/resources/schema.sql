INSERT INTO shipment (track_no, origin, destination, status) VALUES ('TRK0001', 'New York', 'Los Angeles', 'In Transit');
INSERT INTO shipment (track_no, origin, destination, status) VALUES ('TRK0002', 'Chicago', 'Houston', 'Delivered');
INSERT INTO shipment (track_no, origin, destination, status) VALUES ('TRK0003', 'Miami', 'Seattle', 'In Transit');

