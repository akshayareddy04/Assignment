package com.example.shipment_model.service;

import com.example.shipment_model.entity.Shipment;
import com.example.shipment_model.repository.ShipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShipmentService {
    private final ShipmentRepository shipmentRepository;

    @Autowired
    public ShipmentService(ShipmentRepository shipmentRepository) {this.shipmentRepository = shipmentRepository;}

    public Shipment findByShipID(int id) {
        return shipmentRepository.findByShipId(id);
    }

    public Shipment findByTrackNo(String trackNo) {
        Shipment shipment = shipmentRepository.findByTrackNo(trackNo);
        System.out.println("Repository returned: " + shipment);
        return shipment;

    }

    public void deleteShipment(Shipment shipment) {
        shipmentRepository.delete(shipment);
    }

}
