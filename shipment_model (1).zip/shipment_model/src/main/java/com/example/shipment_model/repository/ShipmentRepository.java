package com.example.shipment_model.repository;

import com.example.shipment_model.entity.Shipment;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@EntityScan
@Repository
public interface ShipmentRepository extends JpaRepository<Shipment,Integer> {
    Shipment findByTrackNo(String trackNo);
    Shipment findByShipId(int shipID);


}
