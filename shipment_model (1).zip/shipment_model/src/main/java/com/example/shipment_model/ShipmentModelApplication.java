package com.example.shipment_model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipmentModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipmentModelApplication.class, args);
	}

}
