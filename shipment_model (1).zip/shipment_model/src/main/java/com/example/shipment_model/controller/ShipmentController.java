package com.example.shipment_model.controller;

import com.example.shipment_model.entity.Shipment; // Assuming an entity class for Shipment
import com.example.shipment_model.service.ShipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/shipment")
public class ShipmentController {

    private final ShipmentService shipmentService;

    @Autowired
    public ShipmentController(ShipmentService shipmentService) {
        this.shipmentService = shipmentService;
    }

    @GetMapping("/{trackNo}")
    public ResponseEntity<?> getShipmentByTrackNo(@PathVariable String trackNo) {
        Shipment shipment = shipmentService.findByTrackNo(trackNo);
        System.out.println(shipment);
        System.out.println(trackNo);
        if (shipment == null) {
            return ResponseEntity.status(401).body("Shipment not found");
        }
        return ResponseEntity.ok(shipment);
    }

    @DeleteMapping("/{shipmentId}")
    public ResponseEntity<?> deleteShipment(@PathVariable int shipmentId) {
        Shipment shipment = shipmentService.findByShipID(shipmentId);
        if (shipment == null) {
            return ResponseEntity.status(401).body("Shipment not Found");
        }
        shipmentService.deleteShipment(shipment);
        return ResponseEntity.ok("Successfully deleted"); // Indicate successful deletion without content
    }
}
