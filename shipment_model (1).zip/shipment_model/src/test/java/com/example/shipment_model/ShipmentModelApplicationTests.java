package com.example.shipment_model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShipmentModelApplicationTests {

	@Test
	void contextLoads() {
	}

}
